﻿namespace GestioneDiario
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Gestione di un diario!");

            string path = @"c:\files\diario.txt";
            /*
            Data e ora
            Frase del giorno

            Data e ora
            Frase del giorno

            Data e ora
            Frase del giorno
                          
             */

            string testo = string.Empty;
           if(!File.Exists(path))
                MyLibrary.ScriviFileTesto(path,testo);
                //File.CreateText(path);
            
            //leggo il diario
            
            try {
                testo = MyLibrary.LeggiFileTesto(path);
                Console.WriteLine($"Testo del diario: {testo}");
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex);
            }

            Console.Write("Inserisci la frase del giorno: ");
            string frase=Console.ReadLine();
            testo += (testo.Length!=0 ? "\n":"")+DateTime.Now.ToString() + "\n" + frase;
            
            MyLibrary.ScriviFileTesto(path, testo);
            Console.WriteLine("Operazione eseguita correttamente!");
        }
    }
}