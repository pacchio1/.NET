﻿namespace GestioneFileTesto
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Gestione file di testo!");

            string path = @"c:\files\testo.txt";

            //scrittura
            
            StreamWriter sw = new StreamWriter(path); //apri il file in modalità scrittura

            Console.Write("Inserisci una frase: ");
            string frase = Console.ReadLine();

            sw.WriteLine(frase); //scrivi

            sw.Flush(); //salva tutto

            sw.Close(); //chiudi

            Console.WriteLine("I dati inseriti sono stati salvati su file di testo");
            
            //lettura
            
            try
            {
                StreamReader sr = new StreamReader(path); //apro il file in modalità lettura

                string testo = string.Empty;

                testo = sr.ReadToEnd(); //leggo tutto il contenuto del file

                sr.Close();

                Console.WriteLine($"Testo recuperato dalla lettura del file:\n{testo}");
            }
            catch (FileNotFoundException e)
            {
                Console.WriteLine("Errore!\nFile non trovato!");
                Console.WriteLine($"Errore!{e.Message}");
            }
            catch (Exception e)
            {
                Console.WriteLine($"Errore!{e.Message}");
            }            
        }
    }
}