﻿namespace GestioneLibrettoStudenti
{
    public class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Gestione libretto studenti!");

            var biz = new EsameBiz();

            Console.WriteLine("Elenco esami");
            Console.WriteLine(biz.Stampa());

            Console.WriteLine();
            Console.WriteLine($"Media esami: {biz.MediaEsami()}");

            Console.WriteLine();
            Console.WriteLine("Stampa esami sostenuti da studente");
            Console.Write("Inserisci il cognome dello studente: ");
            string cognome=Console.ReadLine();
            Console.WriteLine(string.Join("\n",biz.EsamiPerStudente(cognome)));

            Console.WriteLine();
            Console.WriteLine("Stampa esami sostenuti in una certa materia");
            Console.Write("Inserisci la materia: ");
            string materia = Console.ReadLine();
            Console.WriteLine(string.Join("\n", biz.EsamiPerMateria(materia)));

            Console.WriteLine();
            Console.WriteLine("Stampa numero di esami sostenuti da studente");
            Console.Write("Inserisci il cognome dello studente: ");
            cognome = Console.ReadLine();
            Console.WriteLine($"Numero di esami sostenuti: {biz.NumeroEsamiPerStudente(cognome)}");

        }
    }
}