﻿using Microsoft.AspNetCore.Mvc;

namespace BikeStores.Controllers
{
    public class Profile : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
