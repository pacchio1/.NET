﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace BikeStores.Controllers
{
    [Authorize]
    public class DashboardController : Controller
    {
        public IActionResult Index()
        {
            var userRoles = User.FindAll(ClaimTypes.Role);
            ViewBag.IsAdmin = userRoles.Any(r => r.Value == "Admin");
            ViewBag.IsEmployee = userRoles.Any(r => r.Value == "Employee");
            ViewBag.IsCustomer = userRoles.Any(r => r.Value == "Customer");
            return View();
        }
    }
}
