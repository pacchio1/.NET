﻿using System;
using System.Collections.Generic;

namespace BikeStores.Models
{
    public partial class OrderStatus
    {
        public string? StatusId { get; set; }
        public string? StatusDescription { get; set; }
    }
}
