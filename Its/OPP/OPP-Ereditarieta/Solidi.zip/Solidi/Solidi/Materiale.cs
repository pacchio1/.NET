﻿namespace Solidi
{
    public enum Materiale
    {
        Alluminio,Acciaio,Rame,Platino,Tungsteno,Bronzo,Piombo
    }
}