﻿namespace Persone
{
    public enum Sesso
    {
        ALTRO, F, M
    }
}