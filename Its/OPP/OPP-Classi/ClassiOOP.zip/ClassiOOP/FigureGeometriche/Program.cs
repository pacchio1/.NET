﻿using System.Runtime.InteropServices;

namespace FigureGeometriche
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Classi OOP!");
            /*
            Quadrato q = new Quadrato(); //istanza
            Console.Write("Inserisci il lato del quadrato: ");
            q.Lato = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine($"Lato: {q.Lato}");
            Console.WriteLine($"Perimetro: {q.Perimetro()}");
            Console.WriteLine($"Area: {q.Area()}");
            Console.WriteLine($"Diagonale: {q.Diagonale()}");
            Console.WriteLine(q);

            var q1 = new Quadrato { Lato = 2.5 };
            Console.WriteLine(q1);
            
            try
            {
                Console.Write("Inserisci il lato 1: ");
                double lato1 = Convert.ToDouble(Console.ReadLine());
                Console.Write("Inserisci il lato 2: ");
                double lato2 = Convert.ToDouble(Console.ReadLine());
                Console.Write("Inserisci il lato 3: ");
                double lato3 = Convert.ToDouble(Console.ReadLine());
                var t1 = new Triangolo(lato1, lato2, lato3);
                Console.WriteLine(t1);
            }catch(Exception ex) {
                Console.WriteLine(ex.Message);
            }
            */

            var p = new Punto { X = 1, Y = 1 };
            var q = new Punto { X = 10, Y = 1 };
            var r = new Punto { X = 0, Y = 1 };

            Console.WriteLine($"OP={p.Distanza()}");
            Console.WriteLine($"OQ={q.Distanza()}");

            Console.WriteLine($"PQ={p.Distanza(q)}");
            Console.WriteLine($"QP={q.Distanza(p)}");
                        
            try
            {
                var t2 = new Triangolo(p, q, r);
                Console.WriteLine(t2);
            }
            catch (Exception ex) {
                Console.WriteLine(ex.ToString());
            }


        }
    }
}