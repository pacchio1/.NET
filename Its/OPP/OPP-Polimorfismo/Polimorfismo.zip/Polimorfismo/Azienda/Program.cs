﻿namespace Azienda
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Azienda petrolchimica!");
        }
    }
}