﻿namespace Azienda
{
    internal enum Settore
    {
        Installatore,Manutentore
    }
}