﻿namespace Azienda
{
    internal enum Mansione
    {
        Contabile,RisorseUmane,Direttore
    }
}