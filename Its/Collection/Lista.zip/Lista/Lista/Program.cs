﻿using FigureGeometriche;
using System.Collections;

namespace Lista
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Collezioni di dati");

            Console.WriteLine("Uso di un ArrayList!");

            var lista = new ArrayList();

            Console.WriteLine($"Capacità: {lista.Capacity}");
            Console.WriteLine($"Dimensione: {lista.Count}");

            //aggiunta di elementi alla lista
            lista.Add("Piero");
            lista.Add(12);
            lista.Add(12.75);
            lista.Add(false);
            lista.Add('@');
            lista.Add(new Quadrato { Lato = 1.25 });
            lista.Add('@');
            Console.WriteLine($"Capacità: {lista.Capacity}");
            Console.WriteLine($"Dimensione: {lista.Count}");

            foreach( var item in lista )
            {
                Console.WriteLine(item);
            }

            Console.WriteLine($"Elemento in posizione 2: {lista[2]}");

            //aggiungo un elemento in posizione 2
            lista.Insert(2, "Giulia");
            for(int i=0;i<lista.Count;i++)
                Console.WriteLine($"{i}: {lista[i]}");

            //rimuovere un oggetto dalla lista
            lista.Remove('@');
            Console.WriteLine("Oggetto '@' rimosso");

            //rimuovo un oggetto dalla lista in posizione 4
            lista.RemoveAt(4);
            Console.WriteLine("Oggetto in posizione 4 rimosso");

            for (int i = 0; i < lista.Count; i++)
                Console.WriteLine($"{i}: {lista[i]}");
        }
    }
}