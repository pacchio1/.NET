﻿namespace ListaNumeriCasuali
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Lista di numeri interi generati casualmente!");
            
            //esempio
            //creo lista di numeri interi generati casualmente [1,100]
            //cerco un numero dato in input
            Random random = new Random();
            var numeri = new List<int>();

            int numeriDaGenerare = random.Next(100) + 1;
            Console.WriteLine($"Numeri generati: {numeriDaGenerare}");

            for (int i = 0; i < numeriDaGenerare; i++)
                numeri.Add(random.Next(100) + 1);

            Console.Write("Inserisci il numero da cercare: ");
            int numero = int.Parse(Console.ReadLine());

            //restituisce la prima posizione dell'elemento richiesto presente nella lista
            int posizione = numeri.IndexOf(numero);
            Console.WriteLine($"{numero} trovato in posizione {posizione}");
            Console.WriteLine(string.Join(", ", numeri));
        }
    }
}