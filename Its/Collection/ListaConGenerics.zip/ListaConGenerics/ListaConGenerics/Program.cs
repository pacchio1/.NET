﻿using FigureGeometriche;

namespace ListaConGenerics
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Lista con Generics!");

            //lista di tipo specifico, numeri interi
            var lista = new List<int>() { 12, 4, -5, -56, 90, 78 };
            Console.WriteLine(string.Join(", ", lista));

            var quadrati = new List<Quadrato> {
            new Quadrato{ Lato=1.25},
                new Quadrato{ Lato=3.25},
            new Quadrato{ Lato=1.75},
            new Quadrato{ Lato=1.35},
            new Quadrato{ Lato=2.25},
            };
            Console.WriteLine(string.Join("\n", quadrati));

            
        }
    }
}