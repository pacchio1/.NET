﻿using System.Xml.Linq;

namespace LinqToXML
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Linq To XML!");

            //connessione ad un file xml mediante LInQ

            string path = @"..\..\..\files\Studenti.xml";

            XElement root = XElement.Load(path);
            
            var studenti = root.Elements().ToList(); //restituisce tutti i record
            foreach (var s in studenti)
            {
                Console.WriteLine(s.Element("Matricola").Value);
            }

            //creo una lista di oggetti Studente
            var lista = root.Elements().Select(s => new Studente
            {
                Matricola = int.Parse(s.Element("Matricola").Value),
                Cognome = s.Element("Cognome").Value,
                Nome = s.Element("Nome").Value,
                Classe = s.Element("Classe").Value
            }).ToList();

            Console.WriteLine(string.Join("\n",lista));
        }
    }
}