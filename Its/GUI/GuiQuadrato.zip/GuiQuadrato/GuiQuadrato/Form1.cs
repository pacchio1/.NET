using FigureGeometriche;

namespace GuiQuadrato
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnInvia_Click(object sender, EventArgs e)
        {
            var q = new Quadrato();

            try
            {
                if (txtLato.Text.Trim().Length == 0)
                    throw new Exception("Il lato � obbligatorio!");

                q.Lato = double.Parse(txtLato.Text);
                lblRisultati.Text = q.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message,"Input dati",MessageBoxButtons.OK,MessageBoxIcon.Error);
            }

            
        }

        private void btnCancella_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Sicuro di voler eliminare i dati visualizzati?", "Cancella", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                lblRisultati.Text = string.Empty;
                txtLato.Text = string.Empty;
            }
        }
    }
}