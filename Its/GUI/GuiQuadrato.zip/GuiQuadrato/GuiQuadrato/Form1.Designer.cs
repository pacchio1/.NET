﻿namespace GuiQuadrato
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblQuadrato = new Label();
            lblLato = new Label();
            txtLato = new TextBox();
            btnInvia = new Button();
            btnCancella = new Button();
            lblRisultati = new Label();
            SuspendLayout();
            // 
            // lblQuadrato
            // 
            lblQuadrato.AutoSize = true;
            lblQuadrato.Location = new Point(158, 23);
            lblQuadrato.Name = "lblQuadrato";
            lblQuadrato.Size = new Size(79, 15);
            lblQuadrato.TabIndex = 0;
            lblQuadrato.Text = "GUI Quadrato";
            // 
            // lblLato
            // 
            lblLato.AutoSize = true;
            lblLato.Location = new Point(59, 70);
            lblLato.Name = "lblLato";
            lblLato.Size = new Size(151, 15);
            lblLato.TabIndex = 1;
            lblLato.Text = "Inserisci il lato del quadrato";
            // 
            // txtLato
            // 
            txtLato.Location = new Point(216, 67);
            txtLato.Name = "txtLato";
            txtLato.Size = new Size(100, 23);
            txtLato.TabIndex = 2;
            // 
            // btnInvia
            // 
            btnInvia.Location = new Point(117, 109);
            btnInvia.Name = "btnInvia";
            btnInvia.Size = new Size(75, 23);
            btnInvia.TabIndex = 3;
            btnInvia.Text = "Invia";
            btnInvia.UseVisualStyleBackColor = true;
            btnInvia.Click += btnInvia_Click;
            // 
            // btnCancella
            // 
            btnCancella.Location = new Point(216, 109);
            btnCancella.Name = "btnCancella";
            btnCancella.Size = new Size(75, 23);
            btnCancella.TabIndex = 5;
            btnCancella.Text = "Cancella";
            btnCancella.UseVisualStyleBackColor = true;
            btnCancella.Click += btnCancella_Click;
            // 
            // lblRisultati
            // 
            lblRisultati.AutoSize = true;
            lblRisultati.Location = new Point(64, 182);
            lblRisultati.Name = "lblRisultati";
            lblRisultati.Size = new Size(0, 15);
            lblRisultati.TabIndex = 6;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(426, 450);
            Controls.Add(lblRisultati);
            Controls.Add(btnCancella);
            Controls.Add(btnInvia);
            Controls.Add(txtLato);
            Controls.Add(lblLato);
            Controls.Add(lblQuadrato);
            Name = "Form1";
            Text = "GUI Quadrato";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblQuadrato;
        private Label lblLato;
        private TextBox txtLato;
        private Button btnInvia;
        private Button btnCancella;
        private Label lblRisultati;
    }
}