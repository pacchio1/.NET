﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;

namespace GuiCatalogo
{
    public class MyLibrary
    {
        public static List<Prodotto> LeggiFileOggetti(string path) {
            
            FileStream fs = new FileStream(path, FileMode.Open, FileAccess.Read);
            BinaryFormatter bf = new BinaryFormatter();
            var elenco = bf.Deserialize(fs) as List<Prodotto>;
            fs.Close();

            return elenco;
        }


        public static void ScriviFileOggetti(string path, List<Prodotto> elenco) {

            FileStream fs = new FileStream(path, FileMode.Create, FileAccess.Write);
                        
            BinaryFormatter bf = new BinaryFormatter();
            bf.Serialize(fs, elenco);

            fs.Close();

        }




    }
}
