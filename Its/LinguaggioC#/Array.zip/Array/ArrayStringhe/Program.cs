﻿
string[] nomi = {"Piero","Giulia","Ilaria","Monica","Andrea"};

foreach (string s in nomi)
    Console.WriteLine(s);