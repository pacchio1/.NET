﻿/*
Dati in input 2 numeri interi, 
calcolare la somma e visualizzare il risultato 
 */

int a, b;

Console.Write("Inserisci un numero intero: ");
string tmp = Console.ReadLine();
a = int.Parse(tmp);

Console.Write("Inserisci un altro numero intero: ");
tmp = Console.ReadLine();
b = int.Parse(tmp);

int somma = a + b;

Console.WriteLine("Somma: "+somma); //stile java
Console.WriteLine("Somma: {0}",somma); //uso segnaposto
Console.WriteLine("{0}+{1}={2}",a,b,somma);
Console.WriteLine($"{a}+{b}={somma}"); //interpolazione


