﻿
char c = 'a';
int posizioneAscii=(int)c;
Console.WriteLine(posizioneAscii);

int pos = 97;
char c2 = (char)pos;
Console.WriteLine(c2);

//numeri reali
float f = (float)12.55;
float f2 = 12.55F;

//interi
byte b; //8 bit
short s; //16 bit
int n; //32 bit
long l; //64 bit

