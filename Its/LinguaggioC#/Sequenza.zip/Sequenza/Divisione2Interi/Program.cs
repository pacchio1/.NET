﻿/*
Dati in input 2 numeri interi,
calcolare il quoziente intero, il resto, il quoziente reale
Visualizzare i risultati
 */

Console.Write("Inserisci il dividendo: ");
int a = int.Parse(Console.ReadLine());

Console.Write("Inserisci il divisore: ");
int b = int.Parse(Console.ReadLine());

//operazioni
int qi = a / b;
int r = a % b;
double qr = (double)a / b; //casting

Console.WriteLine($"Quoziente intero: {qi}");
Console.WriteLine($"resto: {r}");
Console.WriteLine($"Quoziente reale: {qr}");