﻿/*
Dato in input il costo,
stampare la fattura emessa da un libero professionista,
sapendo che laliquota iva è al 22%
sapendo che si applica al costo la rivalsa del 4%
sapendo che si applica la ritenuta d'acconto

esempio
costo:                                  1000,00 euro
rivalsa (4% del costo):                   40,00 euro
imponibile:                             1040,00 euro
iva (22% imponibile):                    228,80 euro
Totale lordo:                           1268,80 euro
Ritenuta d'acconto (20% dell'imponibile) 208,00 euro
Totle netto:                            1060,80 euro
 */

//input
Console.Write("Inserisci il costo: ");
double costo = double.Parse(Console.ReadLine());

//operazioni
double rivalsa = costo * 4 / 100;
double imponibile = costo + rivalsa;
double iva = imponibile * 22 / 100;
double totaleLordo = imponibile + iva;
double ritenutaAcconto = imponibile * 20 / 100;
double totaleNetto = totaleLordo - ritenutaAcconto;

//output
string msg = $"Costo: {costo} euro" +
    $"\nRivalsa: {rivalsa} euro" +
    $"\nImponibile: {imponibile} euro" +
    $"\nIva: {iva} euro" +
    $"\nTotale lordo: {totaleLordo} euro" +
    $"\nRitenuta d'acconto: {ritenutaAcconto} euro" +
    $"\nTotale netto: {totaleNetto} euro";

Console.WriteLine(msg);